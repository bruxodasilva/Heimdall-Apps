<?php

namespace App\SupportedApps\xTeVe;

class xTeVe extends \App\SupportedApps // phpcs:ignore
{
}
