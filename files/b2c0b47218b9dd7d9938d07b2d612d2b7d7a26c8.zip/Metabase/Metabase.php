<?php

namespace App\SupportedApps\Metabase;

class Metabase extends \App\SupportedApps
{
}
