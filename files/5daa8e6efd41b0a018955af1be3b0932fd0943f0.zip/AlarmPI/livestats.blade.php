<ul class="livestats">
    <li>
        <span class="title">Status</span>
        <strong>{!! $alarm_status !!}</strong>
    </li>
    <li>
        <span class="title">Sensors</span>
        <strong>{!! $alarm_sensors !!}</strong>
    </li>
</ul>
