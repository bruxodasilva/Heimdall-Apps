<?php

namespace App\SupportedApps\Kanboard;

class Kanboard extends \App\SupportedApps
{
}
