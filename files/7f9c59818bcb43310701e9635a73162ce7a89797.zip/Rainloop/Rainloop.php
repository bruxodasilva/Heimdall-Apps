<?php

namespace App\SupportedApps\Rainloop;

class Rainloop extends \App\SupportedApps
{
}
