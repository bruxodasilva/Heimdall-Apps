<?php

namespace App\SupportedApps\Unmanic;

class Unmanic extends \App\SupportedApps
{
}
