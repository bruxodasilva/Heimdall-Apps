<ul class="livestats">
    <li>
        <span class="title">Opened</span>
        <strong>{!! $opened !!}</strong>
    </li>
    <li>
        <span class="title">Closed</span>
        <strong>{!! $closed !!}</strong>
    </li>
</ul>
