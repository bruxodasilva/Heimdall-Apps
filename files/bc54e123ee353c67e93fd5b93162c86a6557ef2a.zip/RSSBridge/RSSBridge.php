<?php

namespace App\SupportedApps\RSSBridge;

class RSSBridge extends \App\SupportedApps
{
}
