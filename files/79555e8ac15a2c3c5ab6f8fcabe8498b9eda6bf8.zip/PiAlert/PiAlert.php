<?php

namespace App\SupportedApps\PiAlert;

class PiAlert extends \App\SupportedApps
{
}
