<?php

namespace App\SupportedApps\vmwarehorizon;

class vmwarehorizon extends \App\SupportedApps // phpcs:ignore
{
}
