<?php

namespace App\SupportedApps\Server;

class Server extends \App\SupportedApps
{
}
