<?php

namespace App\SupportedApps\Meraki;

class Meraki extends \App\SupportedApps
{
}
