<?php

namespace App\SupportedApps\Homer;

class Homer extends \App\SupportedApps
{
}
