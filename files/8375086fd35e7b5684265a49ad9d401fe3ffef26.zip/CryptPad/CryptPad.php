<?php

namespace App\SupportedApps\CryptPad;

class CryptPad extends \App\SupportedApps
{
}
