<?php

namespace App\SupportedApps\Grocy;

class Grocy extends \App\SupportedApps
{
}
