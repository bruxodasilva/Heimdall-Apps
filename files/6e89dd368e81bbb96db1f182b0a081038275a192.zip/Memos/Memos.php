<?php

namespace App\SupportedApps\Memos;

class Memos extends \App\SupportedApps
{
}
