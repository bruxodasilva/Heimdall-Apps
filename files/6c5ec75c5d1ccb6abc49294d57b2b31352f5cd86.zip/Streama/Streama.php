<?php

namespace App\SupportedApps\Streama;

class Streama extends \App\SupportedApps
{
}
