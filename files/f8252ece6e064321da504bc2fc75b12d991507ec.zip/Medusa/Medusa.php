<?php

namespace App\SupportedApps\Medusa;

class Medusa extends \App\SupportedApps
{
}
